import React from 'react';
import { Terminal, Trash2 } from 'lucide-react';

interface LogViewerProps {
  logs: string[];
  onClear: () => void;
}

export const LogViewer: React.FC<LogViewerProps> = ({ logs, onClear }) => {
  return (
    <div className="bg-[#0b0c12] border border-[#1e2332] rounded-2xl p-5 space-y-3 font-mono">
      <div className="flex items-center justify-between border-b border-[#1c212e] pb-3">
        <div className="flex items-center gap-2 text-xs font-semibold text-slate-300">
          <Terminal className="w-4 h-4 text-emerald-400" />
          WebHID Real-time Packet & Communication Log
        </div>

        <button
          onClick={onClear}
          className="px-2.5 py-1 rounded-lg bg-[#141722] hover:bg-[#1a1f2e] border border-[#242b3d] text-[11px] text-slate-400 hover:text-slate-200 flex items-center gap-1.5 transition-all"
        >
          <Trash2 className="w-3 h-3" />
          Clear Logs
        </button>
      </div>

      <div className="bg-[#07080c] border border-[#171b26] rounded-xl p-4 h-64 overflow-y-auto space-y-1 text-xs text-slate-300">
        {logs.length === 0 ? (
          <div className="text-slate-600 italic">No packet logs captured yet...</div>
        ) : (
          logs.map((log, i) => (
            <div
              key={i}
              className={`leading-relaxed ${
                log.includes('ERROR') || log.includes('Failed')
                  ? 'text-rose-400 font-semibold'
                  : log.includes('SUCCESS') || log.includes('VERIFIED')
                  ? 'text-emerald-400 font-semibold'
                  : log.includes('TX') || log.includes('Writing')
                  ? 'text-cyan-300'
                  : 'text-slate-400'
              }`}
            >
              {log}
            </div>
          ))
        )}
      </div>
    </div>
  );
};
