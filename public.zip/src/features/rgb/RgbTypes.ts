export interface RgbDeviceMetadata {
  vid: string;
  pid: string;
}

export interface RgbDumpData {
  timestamp: string;
  device: RgbDeviceMetadata;
  command: string;      // e.g. "0x84"
  reportId: string;     // e.g. "0x06" or "6"
  packetIndex: number;
  packetCount: number;
  payloadLength: number;
  bytes: number[];      // Array of byte values (0-255)
  hex: string[];        // Array of 2-digit uppercase/lowercase hex strings
  name?: string;        // Optional friendly name (e.g. "rgb_blue.json")
}

export interface RgbConfigOptions {
  reportId: number;      // default 6
  commandHex: string;    // default "0x84" (GET LED/RGB)
  packetCount: number;   // default 1
  packetIndex: number;   // default 0
  payloadLength: number; // default 519 or 520
}

export interface RgbDiffRow {
  offset: number;
  offsetHex: string;     // e.g. "0x0004"
  valAHex: string;       // e.g. "01"
  valBHex: string;       // e.g. "02"
  valADec: number;
  valBDec: number;
  isChanged: boolean;    // true if changed
}

export type ObservationCategory = 'Observed' | 'Likely' | 'Verified';

export interface RgbObservation {
  id: string;
  offset: number;
  offsetHex: string;
  oldHex: string;
  newHex: string;
  category: ObservationCategory;
  description: string;
}
