import type { RgbDumpData, RgbDiffRow, RgbObservation } from './RgbTypes';

/**
 * Lighting Effect ID mapping discovered from hardware captures
 */
export const VERIFIED_RGB_MODES: Record<number, string> = {
  1: 'Fixed_on (Static)',
  2: 'Respire (Breathing)',
  3: 'Rainbow',
  4: 'Flash_away',
  5: 'Raindrops',
  6: 'Rainbow_wheel',
  7: 'Ripples_shining',
  8: 'Stars_twinkle',
  10: 'Retro_snake',
  11: 'Neon_stream',
  12: 'Reaction',
  13: 'Sine_wave',
  15: 'Rotating windmill',
  16: 'Colorful waterfall',
  17: 'Blossoming',
  21: 'Self-define (Custom)',
};

/**
 * Compares two RGB dumps byte-by-byte.
 * Returns an array of RgbDiffRow records.
 */
export function compareDump(dumpA: RgbDumpData, dumpB: RgbDumpData): RgbDiffRow[] {
  const bytesA = dumpA.bytes || [];
  const bytesB = dumpB.bytes || [];
  const maxLen = Math.max(bytesA.length, bytesB.length);

  const diffs: RgbDiffRow[] = [];

  for (let offset = 0; offset < maxLen; offset++) {
    const valADec = bytesA[offset] !== undefined ? bytesA[offset] : 0;
    const valBDec = bytesB[offset] !== undefined ? bytesB[offset] : 0;

    const valAHex = valADec.toString(16).padStart(2, '0').toUpperCase();
    const valBHex = valBDec.toString(16).padStart(2, '0').toUpperCase();

    const isChanged = valADec !== valBDec;

    diffs.push({
      offset,
      offsetHex: `0x${offset.toString(16).padStart(4, '0').toUpperCase()}`,
      valAHex,
      valBHex,
      valADec,
      valBDec,
      isChanged,
    });
  }

  return diffs;
}

/**
 * Analyzes multiple captures or a pair of dumps to output empirical observations.
 */
export function analyzeRgbDiffs(dumps: RgbDumpData[]): RgbObservation[] {
  if (dumps.length < 2) {
    return [];
  }

  const observations: RgbObservation[] = [];
  const baseline = dumps[0];

  // Compare each subsequent capture against baseline
  for (let i = 1; i < dumps.length; i++) {
    const current = dumps[i];
    const diffs = compareDump(baseline, current);
    const changedDiffs = diffs.filter((d) => d.isChanged);

    if (changedDiffs.length === 0) {
      observations.push({
        id: `obs_no_change_${i}`,
        offset: 0,
        offsetHex: '0x----',
        oldHex: '--',
        newHex: '--',
        category: 'Observed',
        description: `No byte changes detected between "${baseline.name || 'Dump A'}" and "${current.name || 'Dump B'}".`,
      });
      continue;
    }

    // Direct offset change observations
    changedDiffs.forEach((diff) => {
      let desc = `Offset ${diff.offsetHex} changed from ${diff.valAHex} (${diff.valADec}) to ${diff.valBHex} (${diff.valBDec}) between "${baseline.name || 'Dump A'}" and "${current.name || 'Dump B'}".`;
      let category: 'Observed' | 'Likely' | 'Verified' = 'Observed';

      // 1. Verified Lighting Effect Mode ID at Offset 0x0011 (Byte 17)
      if (diff.offset === 0x0011 || diff.offsetHex === '0x0011') {
        const oldMode = VERIFIED_RGB_MODES[diff.valADec] || `Mode 0x${diff.valAHex}`;
        const newMode = VERIFIED_RGB_MODES[diff.valBDec] || `Mode 0x${diff.valBHex}`;
        desc = `[VERIFIED LIGHT EFFECT MODE ID] Offset 0x0011 transitioned from ${oldMode} (${diff.valAHex}) to ${newMode} (${diff.valBHex}).`;
        category = 'Verified';
      }

      // 2. Verified Brightness Control at Offset 0x0041 (Byte 65)
      else if (diff.offset === 0x0041 || diff.offsetHex === '0x0041') {
        desc = `[VERIFIED BRIGHTNESS LEVEL] Offset 0x0041 changed from Level ${diff.valADec} to Level ${diff.valBDec}.`;
        category = 'Verified';
      }

      // 3. Verified Color Mode / Custom Color Flag at Offset 0x0010 (Byte 16)
      else if (diff.offset === 0x0010 || diff.offsetHex === '0x0010') {
        desc = `[VERIFIED COLOR MODE FLAG] Offset 0x0010 changed from ${diff.valAHex} to ${diff.valBHex} (Colourful vs Fixed/Custom Color).`;
        category = 'Verified';
      }

      observations.push({
        id: `obs_diff_${diff.offset}_${i}`,
        offset: diff.offset,
        offsetHex: diff.offsetHex,
        oldHex: diff.valAHex,
        newHex: diff.valBHex,
        category,
        description: desc,
      });
    });

    // Candidate RGB triples detection (3 consecutive changed bytes)
    for (let j = 0; j < changedDiffs.length - 2; j++) {
      const d1 = changedDiffs[j];
      const d2 = changedDiffs[j + 1];
      const d3 = changedDiffs[j + 2];

      if (d2.offset === d1.offset + 1 && d3.offset === d1.offset + 2) {
        observations.push({
          id: `obs_rgb_triple_${d1.offset}_${i}`,
          offset: d1.offset,
          offsetHex: `${d1.offsetHex}..${d3.offsetHex}`,
          oldHex: `${d1.valAHex} ${d2.valAHex} ${d3.valAHex}`,
          newHex: `${d1.valBHex} ${d2.valBHex} ${d3.valBHex}`,
          category: 'Likely',
          description: `Candidate RGB Triple detected at offsets ${d1.offsetHex}-${d3.offsetHex}. 3 consecutive bytes modified simultaneously: R=${d1.valBHex}, G=${d2.valBHex}, B=${d3.valBHex}.`,
        });
      }
    }
  }

  return observations;
}
