import React, { useState } from 'react';
import { webhid } from '../../services/webhid';
import { updateRgbSettings, DEFAULT_RGB_CONFIG_OPTIONS } from './RgbProtocol';

interface RgbControlPanelProps {
  isConnected: boolean;
  onConnect: () => void;
  onPayloadUpdated?: (newPayload: Uint8Array) => void;
}

export const RGB_MODES_LIST = [
  { id: 1, name: 'Fixed_on', label: 'Fixed On (Static)', icon: '💡' },
  { id: 2, name: 'Respire', label: 'Respire (Breathing)', icon: '🫁' },
  { id: 3, name: 'Rainbow', label: 'Rainbow', icon: '🌈' },
  { id: 4, name: 'Flash_away', label: 'Flash Away', icon: '⚡' },
  { id: 5, name: 'Raindrops', label: 'Raindrops', icon: '🌧️' },
  { id: 6, name: 'Rainbow_wheel', label: 'Rainbow Wheel', icon: '🎡' },
  { id: 7, name: 'Ripples_shining', label: 'Ripples Shining', icon: '🌊' },
  { id: 8, name: 'Stars_twinkle', label: 'Stars Twinkle', icon: '✨' },
  { id: 10, name: 'Retro_snake', label: 'Retro Snake', icon: '🐍' },
  { id: 11, name: 'Neon_stream', label: 'Neon Stream', icon: '🔮' },
  { id: 12, name: 'Reaction', label: 'Reaction', icon: '🎯' },
  { id: 13, name: 'Sine_wave', label: 'Sine Wave', icon: '〰️' },
  { id: 15, name: 'Rotating_windmill', label: 'Rotating Windmill', icon: '🌀' },
  { id: 16, name: 'Colorful_waterfall', label: 'Colorful Waterfall', icon: '⛲' },
  { id: 17, name: 'Blossoming', label: 'Blossoming', icon: '🌸' },
  { id: 21, name: 'Self_define', label: 'Self Define (Custom)', icon: '🎨' },
];

export const PRESET_COLORS = [
  { name: 'Red', hex: '#FF0000' },
  { name: 'Orange', hex: '#FF7F00' },
  { name: 'Yellow', hex: '#FFFF00' },
  { name: 'Green', hex: '#00FF00' },
  { name: 'Cyan', hex: '#00FFFF' },
  { name: 'Blue', hex: '#0000FF' },
  { name: 'Purple', hex: '#8A2BE2' },
  { name: 'White', hex: '#FFFFFF' },
];

export const RgbControlPanel: React.FC<RgbControlPanelProps> = ({
  isConnected,
  onConnect,
  onPayloadUpdated,
}) => {
  const [selectedModeId, setSelectedModeId] = useState<number>(1); // Default Fixed_on
  const [brightness, setBrightness] = useState<number>(9);         // Default 9
  const [colorFlag, setColorFlag] = useState<number>(1);           // 1 = Custom color, 0 = Colourful
  const [hexColor, setHexColor] = useState<string>('#0000FF');     // Default Blue

  const [isApplying, setIsApplying] = useState<boolean>(false);
  const [statusMsg, setStatusMsg] = useState<string | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const handleApplyRgb = async () => {
    setErrorMsg(null);
    setStatusMsg(null);
    setIsApplying(true);

    try {
      let device = webhid.getDevice();

      if (!device || !device.opened) {
        const hidNav = (navigator as any).hid;
        if (hidNav) {
          const devices = await hidNav.getDevices();
          device = devices.find(
            (d: any) => d.vendorId === 0x258A && d.productId === 0x010C
          );
          if (device && !device.opened) {
            await device.open();
          }
        }
      }

      if (!device || !device.opened) {
        throw new Error('AULA F75 WebHID device is not connected. Click "Connect Keyboard" in the left sidebar first.');
      }

      setStatusMsg('Sending Command 0x04 (SET RGB) to AULA F75...');

      const updatedBytes = await updateRgbSettings(
        device,
        selectedModeId,
        brightness,
        colorFlag,
        hexColor,
        DEFAULT_RGB_CONFIG_OPTIONS
      );

      setStatusMsg('RGB lighting updated successfully on hardware!');
      if (onPayloadUpdated) {
        onPayloadUpdated(updatedBytes);
      }
    } catch (err: any) {
      setErrorMsg(err.message || 'Failed to update RGB settings on hardware.');
    } finally {
      setIsApplying(false);
    }
  };

  return (
    <div className="bg-[#111111] border border-[#222222] rounded-2xl p-6 space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 border-b border-[#1f1f1f] pb-4">
        <div>
          <div className="flex items-center gap-3">
            <h3 className="text-lg font-bold text-white tracking-tight">
              AULA F75 Hardware RGB Lighting Control
            </h3>
            <span className="px-2.5 py-0.5 rounded-full text-[10px] font-mono font-semibold bg-emerald-500/10 text-emerald-400 border border-emerald-500/30">
              HARDWARE WRITE READY
            </span>
          </div>
          <p className="text-xs text-zinc-400 mt-0.5">
            Select light effect modes, brightness levels, and custom colors to update your keyboard live over WebHID.
          </p>
        </div>

        <button
          onClick={handleApplyRgb}
          disabled={isApplying || !isConnected}
          className="bg-emerald-600 hover:bg-emerald-500 disabled:opacity-40 text-white font-bold text-xs px-5 py-2.5 rounded-xl shadow-lg transition-all flex items-center gap-2"
        >
          {isApplying ? (
            <>
              <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
              <span>Updating Hardware...</span>
            </>
          ) : (
            <>
              <span>⚡ Apply RGB Settings</span>
            </>
          )}
        </button>
      </div>

      {/* Banners */}
      {errorMsg && (
        <div className="p-3 bg-rose-500/10 border border-rose-500/30 rounded-xl text-xs text-rose-300 font-medium flex items-center justify-between">
          <span>⚠️ {errorMsg}</span>
          <button onClick={() => setErrorMsg(null)} className="text-rose-400 hover:text-white font-bold">✕</button>
        </div>
      )}

      {statusMsg && (
        <div className="p-3 bg-emerald-500/10 border border-emerald-500/30 rounded-xl text-xs text-emerald-300 font-medium font-mono">
          ✓ {statusMsg}
        </div>
      )}

      {/* Controls Grid */}
      <div className="grid grid-cols-1 md:grid-cols-12 gap-6">
        {/* Left Column: Light Effect Mode Selector (7 cols) */}
        <div className="md:col-span-7 space-y-3">
          <label className="text-xs font-bold text-zinc-400 uppercase tracking-wider font-mono">
            LIGHT EFFECT MODE ({RGB_MODES_LIST.length} verified modes)
          </label>
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 max-h-64 overflow-y-auto pr-1">
            {RGB_MODES_LIST.map((mode) => {
              const isSelected = mode.id === selectedModeId;
              return (
                <button
                  key={mode.id}
                  onClick={() => setSelectedModeId(mode.id)}
                  className={`p-2.5 rounded-xl border text-left text-xs transition-all flex items-center gap-2 font-mono ${
                    isSelected
                      ? 'bg-emerald-500/15 border-emerald-500 text-emerald-300 font-bold shadow-[0_0_10px_rgba(16,185,129,0.15)]'
                      : 'bg-[#151515] border-[#252525] text-zinc-400 hover:border-zinc-700 hover:text-zinc-200'
                  }`}
                >
                  <span className="text-sm">{mode.icon}</span>
                  <span className="truncate">{mode.label}</span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Right Column: Brightness & Color Controls (5 cols) */}
        <div className="md:col-span-5 space-y-5 bg-[#151515] border border-[#252525] rounded-xl p-4">
          {/* Brightness Slider */}
          <div className="space-y-2">
            <div className="flex items-center justify-between text-xs font-mono">
              <span className="font-bold text-zinc-300">BRIGHTNESS LEVEL</span>
              <span className="text-emerald-400 font-bold">Level {brightness} / 9</span>
            </div>
            <input
              type="range"
              min={1}
              max={9}
              value={brightness}
              onChange={(e) => setBrightness(Number(e.target.value))}
              className="w-full accent-emerald-500 cursor-pointer"
            />
            <div className="flex justify-between text-[10px] text-zinc-600 font-mono">
              <span>Min (1)</span>
              <span>Max (9)</span>
            </div>
          </div>

          {/* Color Mode Flag */}
          <div className="flex items-center justify-between pt-2 border-t border-[#222]">
            <span className="text-xs font-mono text-zinc-400 font-medium">COLOR MODE</span>
            <label className="flex items-center gap-2 text-xs font-mono text-zinc-300 cursor-pointer">
              <input
                type="checkbox"
                checked={colorFlag === 0}
                onChange={(e) => setColorFlag(e.target.checked ? 0 : 1)}
                className="rounded accent-emerald-500"
              />
              Colourful Preset
            </label>
          </div>

          {/* Color Picker & Palette (Enabled when colorFlag === 1) */}
          <div className={`space-y-3 pt-2 border-t border-[#222] ${colorFlag === 0 ? 'opacity-40 pointer-events-none' : ''}`}>
            <div className="flex items-center justify-between">
              <span className="text-xs font-mono font-bold text-zinc-300">STATIC COLOR</span>
              <div className="flex items-center gap-2">
                <input
                  type="color"
                  value={hexColor}
                  onChange={(e) => setHexColor(e.target.value.toUpperCase())}
                  className="w-7 h-7 rounded border-0 bg-transparent cursor-pointer"
                />
                <span className="text-xs font-mono text-emerald-400 font-bold">{hexColor}</span>
              </div>
            </div>

            {/* Quick Color Swatches */}
            <div className="grid grid-cols-4 gap-2">
              {PRESET_COLORS.map((c) => (
                <button
                  key={c.name}
                  onClick={() => setHexColor(c.hex)}
                  title={`${c.name} (${c.hex})`}
                  className={`h-7 rounded-lg border transition-all ${
                    hexColor.toUpperCase() === c.hex.toUpperCase()
                      ? 'border-white scale-105 shadow-md'
                      : 'border-transparent opacity-80 hover:opacity-100'
                  }`}
                  style={{ backgroundColor: c.hex }}
                />
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
