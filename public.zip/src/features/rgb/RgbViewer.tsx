import React, { useMemo } from 'react';
import type { RgbDumpData, RgbDiffRow } from './RgbTypes';

interface RgbViewerProps {
  dump: RgbDumpData;
  comparisonDump?: RgbDumpData | null;
  diffs?: RgbDiffRow[];
  highlightOnlyChanged?: boolean;
}

export const RgbViewer: React.FC<RgbViewerProps> = ({
  dump,
  comparisonDump,
  diffs,
  highlightOnlyChanged = false,
}) => {
  const bytes = dump.bytes || [];

  // Map of changed offsets for fast lookup
  const changedSet = useMemo(() => {
    const set = new Set<number>();
    if (diffs) {
      diffs.forEach((d) => {
        if (d.isChanged) set.add(d.offset);
      });
    } else if (comparisonDump) {
      const compBytes = comparisonDump.bytes || [];
      for (let i = 0; i < Math.max(bytes.length, compBytes.length); i++) {
        if (bytes[i] !== compBytes[i]) {
          set.add(i);
        }
      }
    }
    return set;
  }, [diffs, comparisonDump, bytes]);

  // Group bytes into 16-byte rows
  const rows = useMemo(() => {
    const rowList: {
      offset: number;
      offsetHex: string;
      bytes: { valDec: number; valHex: string; offset: number; isChanged: boolean }[];
      ascii: string;
    }[] = [];

    for (let i = 0; i < bytes.length; i += 16) {
      const chunk = bytes.slice(i, i + 16);
      const rowBytes = chunk.map((val, idx) => {
        const offset = i + idx;
        const isChanged = changedSet.has(offset);
        return {
          valDec: val,
          valHex: val.toString(16).padStart(2, '0').toUpperCase(),
          offset,
          isChanged,
        };
      });

      // Filter rows if highlightOnlyChanged is true
      const hasChange = rowBytes.some((b) => b.isChanged);
      if (highlightOnlyChanged && !hasChange) {
        continue;
      }

      const ascii = chunk
        .map((b) => (b >= 32 && b <= 126 ? String.fromCharCode(b) : '.'))
        .join('');

      rowList.push({
        offset: i,
        offsetHex: i.toString(16).padStart(4, '0').toUpperCase(),
        bytes: rowBytes,
        ascii,
      });
    }

    return rowList;
  }, [bytes, changedSet, highlightOnlyChanged]);

  return (
    <div className="bg-[#0b0b0b] border border-[#222222] rounded-xl p-4 font-mono text-xs overflow-x-auto space-y-2">
      <div className="flex items-center justify-between border-b border-[#1c1c1c] pb-2 text-[11px] text-zinc-500 font-semibold uppercase tracking-wider">
        <span>HEX VIEWER ({dump.name || 'Current Dump'})</span>
        <div className="flex items-center gap-4">
          <span className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-sm bg-amber-500/30 border border-amber-400 inline-block" />
            Changed Byte ({changedSet.size} total)
          </span>
          <span className="text-zinc-400 font-mono">Payload: {bytes.length} Bytes</span>
        </div>
      </div>

      <div className="space-y-1 pt-1 selection:bg-amber-500 selection:text-black">
        {rows.length === 0 ? (
          <div className="text-zinc-500 py-4 text-center">No changed bytes in this filter range.</div>
        ) : (
          rows.map((row) => (
            <div
              key={row.offset}
              className="flex items-center gap-4 hover:bg-[#151515] px-2 py-0.5 rounded transition-colors"
            >
              {/* Offset header e.g. 0000 */}
              <span className="text-zinc-500 font-bold w-12 shrink-0 select-none">
                {row.offsetHex}
              </span>

              {/* 16 Bytes grid with mid-way gap at 8 */}
              <div className="flex items-center gap-1.5 flex-1">
                {row.bytes.map((b, idx) => (
                  <React.Fragment key={b.offset}>
                    {idx === 8 && <span className="w-2" />}
                    <span
                      title={`Offset: 0x${b.offset.toString(16).padStart(4, '0').toUpperCase()} (${b.offset}) | Dec: ${b.valDec}`}
                      className={`px-1.5 py-0.5 rounded text-center transition-all cursor-default ${
                        b.isChanged
                          ? 'bg-amber-500/25 text-amber-300 font-bold border border-amber-500/50 shadow-[0_0_8px_rgba(245,158,11,0.2)]'
                          : 'text-zinc-300 hover:text-white hover:bg-zinc-800'
                      }`}
                    >
                      {b.valHex}
                    </span>
                  </React.Fragment>
                ))}
              </div>

              {/* ASCII preview */}
              <span className="text-zinc-600 shrink-0 w-36 text-right select-none tracking-widest">
                {row.ascii}
              </span>
            </div>
          ))
        )}
      </div>
    </div>
  );
};
