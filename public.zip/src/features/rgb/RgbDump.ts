import type { RgbDumpData, RgbConfigOptions, RgbDeviceMetadata } from './RgbTypes';

/**
 * Converts a Uint8Array into an RgbDumpData object matching the required JSON format.
 */
export function createRgbDumpData(
  rawData: Uint8Array,
  options: RgbConfigOptions,
  deviceInfo: RgbDeviceMetadata = { vid: '0x258A', pid: '0x010C' },
  customName?: string
): RgbDumpData {
  const bytesArray = Array.from(rawData);
  const hexArray = bytesArray.map((b) => b.toString(16).padStart(2, '0').toUpperCase());

  return {
    timestamp: new Date().toISOString(),
    device: {
      vid: deviceInfo.vid || '0x258A',
      pid: deviceInfo.pid || '0x010C',
    },
    command: options.commandHex || '0x84',
    reportId: `0x${options.reportId.toString(16).padStart(2, '0').toUpperCase()}`,
    packetIndex: options.packetIndex ?? 0,
    packetCount: options.packetCount ?? 1,
    payloadLength: rawData.length,
    bytes: bytesArray,
    hex: hexArray,
    name: customName || `rgb_dump_${new Date().getTime()}.json`,
  };
}

/**
 * Downloads an RgbDumpData object as a formatted JSON file.
 */
export function exportRgbDumpToJson(dump: RgbDumpData, filename?: string): void {
  const jsonStr = JSON.stringify(dump, null, 4);
  const blob = new Blob([jsonStr], { type: 'application/json' });
  const url = URL.createObjectURL(blob);

  const finalName = filename || dump.name || `rgb_dump_${Date.now()}.json`;
  const a = document.createElement('a');
  a.href = url;
  a.download = finalName.endsWith('.json') ? finalName : `${finalName}.json`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

/**
 * Validates and imports an RgbDumpData object from a JSON string.
 */
export function importRgbDumpFromJson(jsonString: string, defaultName?: string): RgbDumpData {
  let parsed: any;
  try {
    parsed = JSON.parse(jsonString);
  } catch (err) {
    throw new Error('Invalid JSON format.');
  }

  if (!parsed || typeof parsed !== 'object') {
    throw new Error('Invalid RGB dump structure.');
  }

  if (!Array.isArray(parsed.bytes) && !Array.isArray(parsed.hex)) {
    throw new Error('RGB dump must contain a "bytes" or "hex" array.');
  }

  // Derive bytes array if missing or convert hex to bytes
  let bytes: number[] = [];
  if (Array.isArray(parsed.bytes)) {
    bytes = parsed.bytes.map((b: any) => Number(b) & 0xFF);
  } else if (Array.isArray(parsed.hex)) {
    bytes = parsed.hex.map((h: string) => parseInt(h, 16) & 0xFF);
  }

  const hex: string[] = bytes.map((b) => b.toString(16).padStart(2, '0').toUpperCase());

  return {
    timestamp: parsed.timestamp || new Date().toISOString(),
    device: {
      vid: parsed.device?.vid || '0x258A',
      pid: parsed.device?.pid || '0x010C',
    },
    command: parsed.command || '0x84',
    reportId: parsed.reportId || '0x06',
    packetIndex: typeof parsed.packetIndex === 'number' ? parsed.packetIndex : 0,
    packetCount: typeof parsed.packetCount === 'number' ? parsed.packetCount : 1,
    payloadLength: parsed.payloadLength || bytes.length,
    bytes,
    hex,
    name: defaultName || parsed.name || 'imported_rgb_dump.json',
  };
}

/**
 * Generates mock RGB dumps for offline testing & demonstration.
 */
export function createMockRgbDump(name: string, variant: 'blue' | 'red' | 'green' | 'brightness_20' | 'brightness_100'): RgbDumpData {
  const len = 519;
  const mockBytes = new Uint8Array(len);
  
  // Base header matching AULA F75 Report 6
  mockBytes[0] = 0x84; // GET RGB command
  mockBytes[1] = 0x00;
  mockBytes[2] = 0x00;
  mockBytes[3] = 0x01;
  mockBytes[4] = 0x00;
  mockBytes[5] = 0x00;
  mockBytes[6] = 0x02;

  // Fill mock patterns
  for (let i = 7; i < len; i++) {
    mockBytes[i] = (i * 7) % 256;
  }

  // Inject variant differences for testing diff analysis
  if (variant === 'blue') {
    mockBytes[0x10] = 0x01; // Mode ID
    mockBytes[0x14] = 0x00; // Red
    mockBytes[0x15] = 0x00; // Green
    mockBytes[0x16] = 0xFF; // Blue
    mockBytes[0x17] = 0x64; // Brightness 100%
    mockBytes[0x18] = 0x03; // Speed
  } else if (variant === 'red') {
    mockBytes[0x10] = 0x01; // Mode ID
    mockBytes[0x14] = 0xFF; // Red
    mockBytes[0x15] = 0x00; // Green
    mockBytes[0x16] = 0x00; // Blue
    mockBytes[0x17] = 0x64; // Brightness 100%
    mockBytes[0x18] = 0x03; // Speed
  } else if (variant === 'green') {
    mockBytes[0x10] = 0x01;
    mockBytes[0x14] = 0x00;
    mockBytes[0x15] = 0xFF;
    mockBytes[0x16] = 0x00;
    mockBytes[0x17] = 0x64;
    mockBytes[0x18] = 0x03;
  } else if (variant === 'brightness_20') {
    mockBytes[0x10] = 0x01;
    mockBytes[0x14] = 0xFF;
    mockBytes[0x15] = 0x00;
    mockBytes[0x16] = 0x00;
    mockBytes[0x17] = 0x14; // Brightness 20% (0x14)
    mockBytes[0x18] = 0x03;
  } else if (variant === 'brightness_100') {
    mockBytes[0x10] = 0x01;
    mockBytes[0x14] = 0xFF;
    mockBytes[0x15] = 0x00;
    mockBytes[0x16] = 0x00;
    mockBytes[0x17] = 0x64; // Brightness 100% (0x64)
    mockBytes[0x18] = 0x03;
  }

  return createRgbDumpData(
    mockBytes,
    { reportId: 6, commandHex: '0x84', packetCount: 1, packetIndex: 0, payloadLength: len },
    { vid: '0x258A', pid: '0x010C' },
    name
  );
}
