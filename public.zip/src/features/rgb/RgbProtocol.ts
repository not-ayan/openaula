import type { RgbConfigOptions } from './RgbTypes';

/**
 * FEATURE FLAG: RGB Write Functionality
 */
export const ENABLE_RGB_WRITE = true;

export const DEFAULT_RGB_CONFIG_OPTIONS: RgbConfigOptions = {
  reportId: 6,
  commandHex: '0x84',
  packetCount: 1,
  packetIndex: 0,
  payloadLength: 519,
};

export function parseHexByte(hexStr: string, defaultVal: number = 0x84): number {
  if (!hexStr) return defaultVal;
  const clean = hexStr.trim().replace(/^0x/i, '');
  const parsed = parseInt(clean, 16);
  return isNaN(parsed) ? defaultVal : parsed & 0xFF;
}

/**
 * Reads base 512-byte RGB data table over WebHID API.
 */
export async function readRgbTable(device: any): Promise<Uint8Array> {
  if (!device || !device.opened) {
    throw new Error('WebHID Device is not connected or opened.');
  }

  const query = new Uint8Array(519);
  query[0] = 0x84; // GET RGB Command
  query[1] = 0;
  query[2] = 0;
  query[3] = 1;    // 1 packet
  query[4] = 0;    // Packet index 0
  query[5] = 0;
  query[6] = 2;    // 512 bytes payload length

  await device.sendFeatureReport(6, query);
  await new Promise((r) => setTimeout(r, 20));

  const res: DataView = await device.receiveFeatureReport(6);
  const data = new Uint8Array(res.buffer, res.byteOffset, res.byteLength);

  // Normalize header byte offset across browsers
  const base = (data[0] === 6 && data[1] === 0x84) ? 1 : (data[0] === 0x84 ? 0 : (data[0] === 6 ? 1 : 0));
  return data.slice(base + 7, base + 519);
}

/**
 * Writes base 512-byte RGB data table over WebHID API (Command 0x04).
 */
export async function writeRgbTable(device: any, table512: Uint8Array): Promise<boolean> {
  if (!ENABLE_RGB_WRITE) {
    throw new Error('RGB Write is disabled. ENABLE_RGB_WRITE is false.');
  }

  if (!device || !device.opened) {
    throw new Error('WebHID Device is not connected or opened.');
  }

  if (table512.length !== 512) {
    throw new Error('RGB table payload must be exactly 512 bytes.');
  }

  const query = new Uint8Array(519);
  query[0] = 0x04; // Command SET RGB
  query[1] = 0;
  query[2] = 0;
  query[3] = 1;    // 1 packet
  query[4] = 0;    // Packet index 0
  query[5] = 0;
  query[6] = 2;    // 512 bytes payload length
  query.set(table512, 7);

  await device.sendFeatureReport(6, query);
  await new Promise((r) => setTimeout(r, 30));
  return true;
}

/**
 * Reads full 519-byte report payload for viewer / dump compatibility.
 */
export async function readRgbConfiguration(
  device: any,
  options: RgbConfigOptions = DEFAULT_RGB_CONFIG_OPTIONS
): Promise<Uint8Array> {
  const tableData = await readRgbTable(device);
  const fullReport = new Uint8Array(519);
  fullReport[0] = parseHexByte(options.commandHex, 0x84);
  fullReport[1] = 0;
  fullReport[2] = 0;
  fullReport[3] = options.packetCount ?? 1;
  fullReport[4] = options.packetIndex ?? 0;
  fullReport[5] = 0;
  fullReport[6] = 2;
  fullReport.set(tableData, 7);
  return fullReport;
}

/**
 * Writes full 519-byte report payload.
 */
export async function writeRgbConfiguration(
  device: any,
  fullPayload: Uint8Array,
  options: RgbConfigOptions = DEFAULT_RGB_CONFIG_OPTIONS
): Promise<boolean> {
  const table512 = fullPayload.length >= 519 ? fullPayload.slice(7, 519) : fullPayload.slice(0, 512);
  return await writeRgbTable(device, table512);
}

/**
 * High-level helper to update RGB Mode, Brightness, Color Flag, and RGB color channels live on hardware.
 */
export async function updateRgbSettings(
  device: any,
  modeId: number,
  brightness: number,
  colorFlag: number,
  rgbHex: string = '#0000FF',
  options: RgbConfigOptions = DEFAULT_RGB_CONFIG_OPTIONS
): Promise<Uint8Array> {
  if (!device || !device.opened) {
    throw new Error('WebHID Device is not connected or opened.');
  }

  // 1. Fetch current 512-byte table as baseline
  let baseTable: Uint8Array;
  try {
    baseTable = await readRgbTable(device);
  } catch (err) {
    baseTable = new Uint8Array(512);
  }

  const working = new Uint8Array(baseTable);

  // 2. Mutate verified offsets in pure 512-byte table
  working[0x10] = colorFlag & 0xFF;         // Offset 0x0010 (Byte 16) -> Color Flag
  working[0x11] = modeId & 0xFF;            // Offset 0x0011 (Byte 17) -> Mode ID
  working[0x41] = brightness & 0xFF;        // Offset 0x0041 (Byte 65) -> Brightness (1-9)

  // Parse Hex color (e.g. #FF0000 -> R: 255, G: 0, B: 0)
  const cleanHex = rgbHex.replace('#', '');
  const r = parseInt(cleanHex.substring(0, 2) || '00', 16);
  const g = parseInt(cleanHex.substring(2, 4) || '00', 16);
  const b = parseInt(cleanHex.substring(4, 6) || '00', 16);

  working[0x14] = r;                        // Offset 0x0014 -> Red
  working[0x15] = g;                        // Offset 0x0015 -> Green
  working[0x16] = b;                        // Offset 0x0016 -> Blue

  // 3. Write 512-byte table to hardware with Command 0x04
  await writeRgbTable(device, working);

  // 4. Read back updated state from hardware
  const updatedTable = await readRgbTable(device);

  // 5. Construct 519-byte report payload for UI & viewer
  const fullReport = new Uint8Array(519);
  fullReport[0] = 0x84;
  fullReport[3] = 1;
  fullReport[6] = 2;
  fullReport.set(updatedTable, 7);

  return fullReport;
}
