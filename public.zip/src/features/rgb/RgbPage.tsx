import React, { useState, useEffect, useRef, useMemo } from 'react';
import type {
  RgbDumpData,
  RgbConfigOptions,
  RgbDiffRow,
  RgbObservation,
} from './RgbTypes';
import {
  readRgbConfiguration,
  DEFAULT_RGB_CONFIG_OPTIONS,
  ENABLE_RGB_WRITE,
} from './RgbProtocol';
import {
  createRgbDumpData,
  exportRgbDumpToJson,
  importRgbDumpFromJson,
  createMockRgbDump,
} from './RgbDump';
import { compareDump, analyzeRgbDiffs } from './RgbDiff';
import { RgbViewer } from './RgbViewer';
import { RgbControlPanel } from './RgbControlPanel';

interface RgbPageProps {
  isConnected: boolean;
  onConnect: () => void;
}

export const RgbPage: React.FC<RgbPageProps> = ({ isConnected, onConnect }) => {
  // Protocol configuration state
  const [configOptions, setConfigOptions] = useState<RgbConfigOptions>(DEFAULT_RGB_CONFIG_OPTIONS);
  const [showConfigDrawer, setShowConfigDrawer] = useState<boolean>(false);

  // Captures Library State
  const [captures, setCaptures] = useState<RgbDumpData[]>([]);
  const [activeDumpIndex, setActiveDumpIndex] = useState<number>(0);
  const [comparisonDumpIndex, setComparisonDumpIndex] = useState<number>(1);

  // UI state
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [statusMsg, setStatusMsg] = useState<string>('Ready for RGB protocol exploration.');
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [onlyChangedFilter, setOnlyChangedFilter] = useState<boolean>(false);

  const fileInputRef = useRef<HTMLInputElement>(null);

  // Initialize with public/dump/rgb_blue.json and preset captures
  useEffect(() => {
    const mockRed = createMockRgbDump('rgb_red.json', 'red');
    const mockGreen = createMockRgbDump('rgb_green.json', 'green');
    const mockB20 = createMockRgbDump('brightness_20.json', 'brightness_20');
    const mockB100 = createMockRgbDump('brightness_100.json', 'brightness_100');

    fetch('/dump/rgb_blue.json')
      .then((res) => {
        if (!res.ok) throw new Error('File not found');
        return res.text();
      })
      .then((jsonStr) => {
        const realBlue = importRgbDumpFromJson(jsonStr, 'rgb_blue.json');
        setCaptures([realBlue, mockRed, mockGreen, mockB20, mockB100]);
        setStatusMsg('Loaded real hardware capture "rgb_blue.json" from /dump/');
      })
      .catch(() => {
        const mockBlue = createMockRgbDump('rgb_blue.json', 'blue');
        setCaptures([mockBlue, mockRed, mockGreen, mockB20, mockB100]);
      });
  }, []);

  const currentDump = captures[activeDumpIndex] || null;
  const comparisonDump = captures[comparisonDumpIndex] || null;

  // Compute diffs between active baseline dump and selected comparison dump
  const diffs: RgbDiffRow[] = useMemo(() => {
    if (!currentDump || !comparisonDump || activeDumpIndex === comparisonDumpIndex) {
      return [];
    }
    return compareDump(currentDump, comparisonDump);
  }, [currentDump, comparisonDump, activeDumpIndex, comparisonDumpIndex]);

  // Compute analysis observations
  const observations: RgbObservation[] = useMemo(() => {
    if (captures.length < 2) return [];
    if (currentDump && comparisonDump && activeDumpIndex !== comparisonDumpIndex) {
      return analyzeRgbDiffs([currentDump, comparisonDump]);
    }
    return analyzeRgbDiffs(captures);
  }, [captures, currentDump, comparisonDump, activeDumpIndex, comparisonDumpIndex]);

  // Filtered diffs for table display
  const displayedDiffs = useMemo(() => {
    if (onlyChangedFilter) {
      return diffs.filter((d) => d.isChanged);
    }
    return diffs;
  }, [diffs, onlyChangedFilter]);

  // Handle Reading RGB via WebHID
  const handleReadRgb = async () => {
    setErrorMsg(null);
    setIsLoading(true);
    setStatusMsg(`Sending Feature Report ${configOptions.reportId} (Command ${configOptions.commandHex})...`);

    try {
      const hidNav = (navigator as any).hid;
      if (!hidNav) {
        throw new Error('WebHID API is not available in this browser.');
      }

      const devices = await hidNav.getDevices();
      const device = devices.find((d: any) => d.opened && d.vendorId === 0x258A && d.productId === 0x010C);

      if (!device) {
        throw new Error('AULA F75 WebHID device is not currently connected or opened. Please click Connect above first.');
      }

      const rawBytes = await readRgbConfiguration(device, configOptions);
      const newDump = createRgbDumpData(
        rawBytes,
        configOptions,
        { vid: '0x258A', pid: '0x010C' },
        `rgb_capture_${captures.length + 1}.json`
      );

      setCaptures((prev) => [...prev, newDump]);
      setActiveDumpIndex(captures.length); // Set as active
      setStatusMsg(`Successfully captured RGB configuration (${rawBytes.length} bytes).`);
    } catch (err: any) {
      setErrorMsg(err.message || 'Failed to read RGB payload.');
      setStatusMsg('RGB Read failed.');
    } finally {
      setIsLoading(false);
    }
  };

  // Import JSON Dump file
  const handleFileLoad = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const jsonContent = event.target?.result as string;
        const imported = importRgbDumpFromJson(jsonContent, file.name);
        setCaptures((prev) => [...prev, imported]);
        setActiveDumpIndex(captures.length);
        setStatusMsg(`Imported "${file.name}" successfully.`);
      } catch (err: any) {
        setErrorMsg(`Failed to import JSON dump: ${err.message}`);
      }
    };
    reader.readAsText(file);
    e.target.value = '';
  };

  return (
    <div className="space-y-6">
      {/* Top Header Card */}
      <div className="bg-[#111111] border border-[#222222] rounded-2xl p-6 relative overflow-hidden space-y-4">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-3">
              <h2 className="text-xl font-bold text-white tracking-tight">
                AULA F75 RGB Configurator & Explorer
              </h2>
              <span className="px-2.5 py-0.5 rounded-full text-[10px] font-mono font-semibold bg-emerald-500/10 text-emerald-400 border border-emerald-500/30">
                LIVE HARDWARE CONTROL ACTIVE
              </span>
            </div>
            <p className="text-xs text-zinc-400 mt-1 max-w-2xl">
              Configure RGB light effects, brightness levels, and static colors live on your keyboard, or inspect, dump, and diff raw Feature Report 0x06 payloads.
            </p>
          </div>

          <div className="flex items-center gap-3">
            {!isConnected ? (
              <button
                onClick={onConnect}
                className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-medium text-xs rounded-xl shadow-lg transition-all flex items-center gap-2"
              >
                <div className="w-2 h-2 rounded-full bg-white animate-pulse" />
                Connect Keyboard
              </button>
            ) : (
              <div className="flex items-center gap-2 px-3 py-1.5 bg-[#181818] border border-[#2a2a2a] rounded-xl text-xs text-emerald-400 font-mono">
                <span className="w-2 h-2 rounded-full bg-emerald-400 shadow-[0_0_8px_#22c55e]" />
                Connected (Report ID 0x06)
              </div>
            )}
          </div>
        </div>

        {/* Status / Error Banners */}
        {errorMsg && (
          <div className="p-3 bg-rose-500/10 border border-rose-500/30 rounded-xl text-xs text-rose-300 font-medium flex items-center justify-between">
            <span>⚠️ {errorMsg}</span>
            <button onClick={() => setErrorMsg(null)} className="text-rose-400 hover:text-white font-bold ml-2">
              ✕
            </button>
          </div>
        )}

        <div className="flex items-center justify-between text-xs text-zinc-400 font-mono pt-2 border-t border-[#1c1c1c]">
          <span className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-blue-500" />
            {statusMsg}
          </span>
          <span className="text-zinc-600">
            ENABLE_RGB_WRITE = <strong className="text-amber-500">{ENABLE_RGB_WRITE ? 'TRUE' : 'FALSE (SAFE)'}</strong>
          </span>
        </div>
      </div>

      {/* Interactive RGB Control Panel */}
      <RgbControlPanel
        isConnected={isConnected}
        onConnect={onConnect}
        onPayloadUpdated={(bytes) => {
          const updatedDump = createRgbDumpData(
            bytes,
            configOptions,
            { vid: '0x258A', pid: '0x010C' },
            `rgb_applied_${Date.now()}.json`
          );
          setCaptures((prev) => [...prev, updatedDump]);
          setActiveDumpIndex(captures.length);
        }}
      />

      {/* Main Action Bar */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        {/* Read RGB Button */}
        <button
          onClick={handleReadRgb}
          disabled={isLoading}
          className="bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 text-white font-semibold text-xs px-4 py-3 rounded-xl shadow-md transition-all flex items-center justify-center gap-2"
        >
          {isLoading ? (
            <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
          ) : (
            <span>📡 Read RGB Configuration</span>
          )}
        </button>

        {/* Config Options Toggle */}
        <button
          onClick={() => setShowConfigDrawer(!showConfigDrawer)}
          className="bg-[#151515] hover:bg-[#202020] border border-[#2a2a2a] text-zinc-300 font-medium text-xs px-4 py-3 rounded-xl transition-all flex items-center justify-center gap-2"
        >
          ⚙️ Protocol Options ({configOptions.commandHex})
        </button>

        {/* Download Current Dump */}
        <button
          onClick={() => currentDump && exportRgbDumpToJson(currentDump)}
          disabled={!currentDump}
          className="bg-[#151515] hover:bg-[#202020] disabled:opacity-40 border border-[#2a2a2a] text-zinc-300 font-medium text-xs px-4 py-3 rounded-xl transition-all flex items-center justify-center gap-2"
        >
          💾 Download JSON Dump
        </button>

        {/* Load Dump File Input */}
        <button
          onClick={() => fileInputRef.current?.click()}
          className="bg-[#151515] hover:bg-[#202020] border border-[#2a2a2a] text-zinc-300 font-medium text-xs px-4 py-3 rounded-xl transition-all flex items-center justify-center gap-2"
        >
          📂 Load JSON Dump
        </button>
        <input
          type="file"
          ref={fileInputRef}
          onChange={handleFileLoad}
          accept=".json"
          className="hidden"
        />
      </div>

      {/* Protocol Options Drawer */}
      {showConfigDrawer && (
        <div className="bg-[#121212] border border-[#262626] rounded-2xl p-5 space-y-4 font-mono text-xs">
          <div className="text-zinc-400 font-bold uppercase tracking-wider text-[11px]">
            PROTOCOL TUNING (RUNTIME CONFIGURABLE)
          </div>
          <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
            <div>
              <label className="block text-zinc-500 mb-1">Report ID</label>
              <input
                type="number"
                value={configOptions.reportId}
                onChange={(e) => setConfigOptions({ ...configOptions, reportId: Number(e.target.value) })}
                className="w-full bg-[#0a0a0a] border border-[#333] rounded-lg px-3 py-1.5 text-white"
              />
            </div>
            <div>
              <label className="block text-zinc-500 mb-1">Command Hex</label>
              <input
                type="text"
                value={configOptions.commandHex}
                onChange={(e) => setConfigOptions({ ...configOptions, commandHex: e.target.value })}
                className="w-full bg-[#0a0a0a] border border-[#333] rounded-lg px-3 py-1.5 text-white"
              />
            </div>
            <div>
              <label className="block text-zinc-500 mb-1">Packet Count</label>
              <input
                type="number"
                value={configOptions.packetCount}
                onChange={(e) => setConfigOptions({ ...configOptions, packetCount: Number(e.target.value) })}
                className="w-full bg-[#0a0a0a] border border-[#333] rounded-lg px-3 py-1.5 text-white"
              />
            </div>
            <div>
              <label className="block text-zinc-500 mb-1">Packet Index</label>
              <input
                type="number"
                value={configOptions.packetIndex}
                onChange={(e) => setConfigOptions({ ...configOptions, packetIndex: Number(e.target.value) })}
                className="w-full bg-[#0a0a0a] border border-[#333] rounded-lg px-3 py-1.5 text-white"
              />
            </div>
            <div>
              <label className="block text-zinc-500 mb-1">Payload Length</label>
              <input
                type="number"
                value={configOptions.payloadLength}
                onChange={(e) => setConfigOptions({ ...configOptions, payloadLength: Number(e.target.value) })}
                className="w-full bg-[#0a0a0a] border border-[#333] rounded-lg px-3 py-1.5 text-white"
              />
            </div>
          </div>
        </div>
      )}

      {/* Captures Library & Comparison Selector */}
      <div className="bg-[#111111] border border-[#222222] rounded-2xl p-6 space-y-4">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 border-b border-[#1f1f1f] pb-4">
          <div>
            <h3 className="text-sm font-bold text-white uppercase tracking-wider">
              CAPTURES EXPERIMENT LIBRARY ({captures.length} captures stored)
            </h3>
            <p className="text-xs text-zinc-500">
              Select Dump A (Baseline) and Dump B (Comparison) to analyze exact byte diffs.
            </p>
          </div>

          <div className="flex items-center gap-4 text-xs">
            <div>
              <span className="text-zinc-500 font-mono mr-2">Baseline A:</span>
              <select
                value={activeDumpIndex}
                onChange={(e) => setActiveDumpIndex(Number(e.target.value))}
                className="bg-[#1a1a1a] border border-[#333] rounded-lg px-3 py-1.5 text-white font-mono"
              >
                {captures.map((c, idx) => (
                  <option key={idx} value={idx}>
                    [{idx + 1}] {c.name || `Dump ${idx + 1}`}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <span className="text-zinc-500 font-mono mr-2">Compare B:</span>
              <select
                value={comparisonDumpIndex}
                onChange={(e) => setComparisonDumpIndex(Number(e.target.value))}
                className="bg-[#1a1a1a] border border-[#333] rounded-lg px-3 py-1.5 text-white font-mono"
              >
                {captures.map((c, idx) => (
                  <option key={idx} value={idx}>
                    [{idx + 1}] {c.name || `Dump ${idx + 1}`}
                  </option>
                ))}
              </select>
            </div>
          </div>
        </div>

        {/* Capture Cards Grid */}
        <div className="flex gap-3 overflow-x-auto pb-2">
          {captures.map((c, idx) => {
            const isA = idx === activeDumpIndex;
            const isB = idx === comparisonDumpIndex;
            return (
              <div
                key={idx}
                onClick={() => {
                  if (!isA) setActiveDumpIndex(idx);
                }}
                className={`shrink-0 w-52 p-3 rounded-xl border transition-all cursor-pointer space-y-1.5 font-mono text-xs ${
                  isA
                    ? 'bg-indigo-600/10 border-indigo-500 text-white shadow-[0_0_12px_rgba(99,102,241,0.2)]'
                    : isB
                    ? 'bg-amber-500/10 border-amber-500 text-amber-200'
                    : 'bg-[#151515] border-[#252525] text-zinc-400 hover:border-zinc-700'
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className="font-bold truncate text-[11px]">{c.name}</span>
                  <div className="flex items-center gap-1">
                    {isA && <span className="px-1.5 py-0.2 bg-indigo-500 text-white text-[9px] rounded font-bold">A</span>}
                    {isB && <span className="px-1.5 py-0.2 bg-amber-500 text-black text-[9px] rounded font-bold">B</span>}
                  </div>
                </div>
                <div className="text-[10px] text-zinc-500 truncate">
                  Cmd: {c.command} | {c.payloadLength}B
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Hex Viewer with Highlights */}
      {currentDump && (
        <RgbViewer
          dump={currentDump}
          comparisonDump={comparisonDump}
          diffs={diffs}
          highlightOnlyChanged={onlyChangedFilter}
        />
      )}

      {/* Diff Table View */}
      {diffs.length > 0 && (
        <div className="bg-[#111111] border border-[#222222] rounded-2xl p-6 space-y-4">
          <div className="flex items-center justify-between border-b border-[#1f1f1f] pb-3">
            <div>
              <h3 className="text-sm font-bold text-white uppercase tracking-wider font-mono">
                DIFF ANALYSIS (A: {currentDump?.name} vs B: {comparisonDump?.name})
              </h3>
              <p className="text-xs text-zinc-500">
                Found {diffs.filter((d) => d.isChanged).length} changed byte offsets out of {diffs.length} total bytes.
              </p>
            </div>

            <button
              onClick={() => setOnlyChangedFilter(!onlyChangedFilter)}
              className={`px-3 py-1.5 rounded-lg text-xs font-mono transition-all border ${
                onlyChangedFilter
                  ? 'bg-amber-500/20 text-amber-300 border-amber-500'
                  : 'bg-[#181818] text-zinc-400 border-[#333] hover:text-white'
              }`}
            >
              {onlyChangedFilter ? 'Showing Changed Bytes Only' : 'Show All Offsets'}
            </button>
          </div>

          <div className="overflow-x-auto max-h-80 overflow-y-auto">
            <table className="w-full text-left font-mono text-xs border-collapse">
              <thead>
                <tr className="border-b border-[#222] text-zinc-500 text-[11px] uppercase">
                  <th className="py-2 px-3">Offset</th>
                  <th className="py-2 px-3">Old (Dump A)</th>
                  <th className="py-2 px-3">New (Dump B)</th>
                  <th className="py-2 px-3 text-center">Changed</th>
                </tr>
              </thead>
              <tbody>
                {displayedDiffs.map((row) => (
                  <tr
                    key={row.offset}
                    className={`border-b border-[#181818] transition-colors ${
                      row.isChanged ? 'bg-amber-500/10 text-amber-200 hover:bg-amber-500/20' : 'text-zinc-500'
                    }`}
                  >
                    <td className="py-1.5 px-3 font-bold text-zinc-300">{row.offsetHex}</td>
                    <td className="py-1.5 px-3 font-mono">{row.valAHex} ({row.valADec})</td>
                    <td className="py-1.5 px-3 font-mono">{row.valBHex} ({row.valBDec})</td>
                    <td className="py-1.5 px-3 text-center font-bold text-amber-400">
                      {row.isChanged ? '✓' : ''}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Analysis Observations Panel */}
      {observations.length > 0 && (
        <div className="bg-[#111111] border border-[#222222] rounded-2xl p-6 space-y-4">
          <div className="border-b border-[#1f1f1f] pb-3">
            <h3 className="text-sm font-bold text-white uppercase tracking-wider font-mono">
              AUTOMATIC ANALYSIS OBSERVATIONS ({observations.length} items)
            </h3>
            <p className="text-xs text-zinc-500">
              Empirical observations derived from byte delta analysis. Zero baseless guessing.
            </p>
          </div>

          <div className="space-y-2 max-h-72 overflow-y-auto pr-1">
            {observations.map((obs) => {
              const badgeColor =
                obs.category === 'Verified'
                  ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40'
                  : obs.category === 'Likely'
                  ? 'bg-amber-500/20 text-amber-300 border-amber-500/40'
                  : 'bg-blue-500/20 text-blue-300 border-blue-500/40';

              return (
                <div
                  key={obs.id}
                  className="p-3 bg-[#151515] border border-[#252525] rounded-xl text-xs space-y-1 font-mono"
                >
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-zinc-200">
                      Offset {obs.offsetHex}: {obs.oldHex} → {obs.newHex}
                    </span>
                    <span className={`px-2 py-0.5 rounded text-[10px] font-bold border ${badgeColor}`}>
                      {obs.category}
                    </span>
                  </div>
                  <p className="text-zinc-400 font-sans text-[12px]">{obs.description}</p>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
};
